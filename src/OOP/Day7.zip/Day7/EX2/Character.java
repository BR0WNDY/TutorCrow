package OOP.Day7.EX2;

public class Character {
    String name;
    int health;
    String weapon;
    int level;

    public Character (String name,int health,String weapon , int level){
        this.name = name;
        this.health = health;
        this.weapon = weapon;
        this.level  = level;
    }

}
