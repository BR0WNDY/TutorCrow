package OOP.Day7.EX1;

public class Food {
    String name;
    int price;
    String restaurant;
    boolean isAvaliable;

    public Food (String name,int price , String restaurant, boolean isAvaliable){
        this.name = name;
        this.price = price;
        this.restaurant = restaurant;
        this.isAvaliable = isAvaliable;
    }
}
